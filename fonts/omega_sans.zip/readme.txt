This version of Omega Sans is for Commercial & Personal use

https://www.ajtypography.com/

https://www.behance.net/anthonyjames